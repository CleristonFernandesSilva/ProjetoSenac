# Projeto-Integrador-SENAC
Projeto Integrador Senac - 1º Semestre / 1ºB
Este projeto foi desenvolvido por: Arthur Silva, Cleriston Fernandes, Jonathan Costa e Julio Cesar

A data de inicio de desenvolvimento foi 01/09/2022 e terminado na data 15/11/2022

IDE: Eclipse 2022-06 (4.24.0)
OBS: O arquivo .java está na pasta src.

O tema do projeto é: Desenvolver um jogo RPG Text.

Foi realizado o desenvolvimento do jogo. Optamos por criar um jogo com a tematica de um personagem que esta ingressando em uma escola de magia. Nessa escola ele vai ter que cumprir uma serie de desafios, batalhas e resolver enigmas para conseguir zerar o jogo.

O algoritmo pensado para desenvolver o jogo relacionado com o tema foi:
  1 Escola
    7 salas(personagem){"Cada sala tem suas peculiaridades e carrega o personagem como parametro."}

Foi utilizado para estruturar o código do projeto:
Funcoes
Listas
Laços de repetição
Condicionais

Cada integrante do grupo ficou responsavel por desenvolver 2 salas.

Divisão das atividades e desenvolvimento de cada sala:
  Jonathan: Menu / HallEscola / SalaAula
  Cleriston: Floresta / CavernaDragao
  Julio: Biblioteca / SalaEscondida
  Arthur: CorredorZelador / SotaoFinal
  
